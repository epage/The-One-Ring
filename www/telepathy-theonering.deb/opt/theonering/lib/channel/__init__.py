#!/usr/bin/env python

import contact_list
import text
import call
import debug_prompt
import debug_log
