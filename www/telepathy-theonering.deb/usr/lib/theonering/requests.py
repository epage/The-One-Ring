import logging

import tp


_moduleLogger = logging.getLogger('requests')


class RequestsMixin(tp.ConnectionInterfaceRequests):

	pass
