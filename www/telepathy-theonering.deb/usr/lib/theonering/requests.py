import logging

import tp


_moduleLogger = logging.getLogger(__name__)


class RequestsMixin(tp.ConnectionInterfaceRequests):

	pass
