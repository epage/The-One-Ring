import tp


class Debug(tp.Debug):

	def __init__(self, connManager):
		tp.Debug.__init__(self, connManager)
